(function(e) {
    function n(n) {
        for (var a, r, s = n[0], c = n[1], u = n[2], g = 0, l = []; g < s.length; g++) r = s[g], Object.prototype.hasOwnProperty.call(o, r) && o[r] && l.push(o[r][0]), o[r] = 0;
        for (a in c) Object.prototype.hasOwnProperty.call(c, a) && (e[a] = c[a]);
        p && p(n);
        while (l.length) l.shift()();
        return i.push.apply(i, u || []), t()
    }

    function t() {
        for (var e, n = 0; n < i.length; n++) {
            for (var t = i[n], a = !0, r = 1; r < t.length; r++) {
                var c = t[r];
                0 !== o[c] && (a = !1)
            }
            a && (i.splice(n--, 1), e = s(s.s = t[0]))
        }
        return e
    }
    var a = {},
        o = {
            index: 0
        },
        i = [];

    function r(e) {
        return s.p + "static/js/" + ({
            "pages-agent-balance": "pages-agent-balance",
            "pages-agent-balancelog~pages-agent-rebateorder~pages-agent-tixianlog~pages-my-record": "pages-agent-balancelog~pages-agent-rebateorder~pages-agent-tixianlog~pages-my-record",
            "pages-agent-balancelog": "pages-agent-balancelog",
            "pages-agent-rebateorder": "pages-agent-rebateorder",
            "pages-agent-tixianlog": "pages-agent-tixianlog",
            "pages-my-record": "pages-my-record",
            "pages-agent-haibao": "pages-agent-haibao",
            "pages-agent-index": "pages-agent-index",
            "pages-agent-links": "pages-agent-links",
            "pages-agent-lirun~pages-index-index~pages-my-apply~pages-my-my~pages-other-helps": "pages-agent-lirun~pages-index-index~pages-my-apply~pages-my-my~pages-other-helps",
            "pages-agent-lirun": "pages-agent-lirun",
            "pages-index-index": "pages-index-index",
            "pages-my-apply": "pages-my-apply",
            "pages-my-my": "pages-my-my",
            "pages-other-helps": "pages-other-helps",
            "pages-agent-poster": "pages-agent-poster",
            "pages-agent-yaoqinlog": "pages-agent-yaoqinlog",
            "pages-index-paysus": "pages-index-paysus",
            "pages-login-loginpwd": "pages-login-loginpwd",
            "pages-login-oauth": "pages-login-oauth",
            "pages-other-doc": "pages-other-doc",
            "pages-other-tagline": "pages-other-tagline"
        } [e] || e) + "." + {
            "pages-agent-balance": "ca0bb8fc",
            "pages-agent-balancelog~pages-agent-rebateorder~pages-agent-tixianlog~pages-my-record": "86b10968",
            "pages-agent-balancelog": "ad128346",
            "pages-agent-rebateorder": "f1fcd549",
            "pages-agent-tixianlog": "32563559",
            "pages-my-record": "66dd5eb5",
            "pages-agent-haibao": "12c4cffc",
            "pages-agent-index": "ce73a63d",
            "pages-agent-links": "31babc7d",
            "pages-agent-lirun~pages-index-index~pages-my-apply~pages-my-my~pages-other-helps": "9155b8dc",
            "pages-agent-lirun": "38bca79f",
            "pages-index-index": "5ec24da1",
            "pages-my-apply": "d8c7279f",
            "pages-my-my": "c659c74a",
            "pages-other-helps": "df7ff299",
            "pages-agent-poster": "908e45fc",
            "pages-agent-yaoqinlog": "fa69ae88",
            "pages-index-paysus": "ee60a58d",
            "pages-login-loginpwd": "eb575b31",
            "pages-login-oauth": "8634ae3d",
            "pages-other-doc": "bbaf1628",
            "pages-other-tagline": "6ed90519"
        } [e] + ".js"
    }

    function s(n) {
        if (a[n]) return a[n].exports;
        var t = a[n] = {
            i: n,
            l: !1,
            exports: {}
        };
        return e[n].call(t.exports, t, t.exports, s), t.l = !0, t.exports
    }
    s.e = function(e) {
        var n = [],
            t = o[e];
        if (0 !== t)
            if (t) n.push(t[2]);
            else {
                var a = new Promise((function(n, a) {
                    t = o[e] = [n, a]
                }));
                n.push(t[2] = a);
                var i, c = document.createElement("script");
                c.charset = "utf-8", c.timeout = 120, s.nc && c.setAttribute("nonce", s.nc), c.src = r(e);
                var u = new Error;
                i = function(n) {
                    c.onerror = c.onload = null, clearTimeout(g);
                    var t = o[e];
                    if (0 !== t) {
                        if (t) {
                            var a = n && ("load" === n.type ? "missing" : n.type),
                                i = n && n.target && n.target.src;
                            u.message = "Loading chunk " + e + " failed.\n(" + a + ": " + i + ")", u.name = "ChunkLoadError", u.type = a, u.request = i, t[1](u)
                        }
                        o[e] = void 0
                    }
                };
                var g = setTimeout((function() {
                    i({
                        type: "timeout",
                        target: c
                    })
                }), 12e4);
                c.onerror = c.onload = i, document.head.appendChild(c)
            } return Promise.all(n)
    }, s.m = e, s.c = a, s.d = function(e, n, t) {
        s.o(e, n) || Object.defineProperty(e, n, {
            enumerable: !0,
            get: t
        })
    }, s.r = function(e) {
        "undefined" !== typeof Symbol && Symbol.toStringTag && Object.defineProperty(e, Symbol.toStringTag, {
            value: "Module"
        }), Object.defineProperty(e, "__esModule", {
            value: !0
        })
    }, s.t = function(e, n) {
        if (1 & n && (e = s(e)), 8 & n) return e;
        if (4 & n && "object" === typeof e && e && e.__esModule) return e;
        var t = Object.create(null);
        if (s.r(t), Object.defineProperty(t, "default", {
            enumerable: !0,
            value: e
        }), 2 & n && "string" != typeof e)
            for (var a in e) s.d(t, a, function(n) {
                return e[n]
            }.bind(null, a));
        return t
    }, s.n = function(e) {
        var n = e && e.__esModule ? function() {
            return e["default"]
        } : function() {
            return e
        };
        return s.d(n, "a", n), n
    }, s.o = function(e, n) {
        return Object.prototype.hasOwnProperty.call(e, n)
    }, s.p = "/", s.oe = function(e) {
        throw console.error(e), e
    };
    var c = window["webpackJsonp"] = window["webpackJsonp"] || [],
        u = c.push.bind(c);
    c.push = n, c = c.slice();
    for (var g = 0; g < c.length; g++) n(c[g]);
    var p = u;
    i.push([0, "chunk-vendors"]), t()
})({
    0: function(e, n, t) {
        e.exports = t("019f")
    },
    "019f": function(e, n, t) {
        "use strict";
        var a = t("4ea4"),
            o = a(t("5530"));
        t("e260"), t("e6cf"), t("cca6"), t("a79d"), t("8588"), t("06b9");
        var i = a(t("e143")),
            r = a(t("7a86")),
            s = a(t("d065")),
            c = a(t("58cb")),
            u = a(t("17a6"));
        i.default.config.productionTip = !1, r.default.mpType = "app", i.default.use(s.default), i.default.use(c.default), i.default.use(u.default);
        var g = new i.default((0, o.default)({}, r.default));
        g.$mount()
    },
    "17a6": function(e, n, t) {
        "use strict";
        Object.defineProperty(n, "__esModule", {
            value: !0
        }), n.default = void 0;
        var a = {
            install: function(e, n) {
                e.prototype.setUserinfo = function(e) {
                    return uni.setStorageSync("userinfo", JSON.stringify(e)), e
                }, e.prototype.getUserinfo = function(e) {
                    e = uni.getStorageSync("userinfo") ? JSON.parse(uni.getStorageSync("userinfo")) : {};
                    return e
                }, e.prototype.islogin = function(e) {
                    return !(!uni.getStorageSync("userinfo") || !uni.getStorageSync("token"))
                }, e.prototype.setHomepageurl = function(e) {
                    return sessionStorage.setItem("homepageurl", sessionStorage.getItem("homepageurl") ? sessionStorage.getItem("homepageurl") : e), e
                }, e.prototype.getHomepageurl = function() {
                    var e = sessionStorage.getItem("homepageurl") || "";
                    return e
                }
            }
        };
        n.default = a
    },
    "222c": function(e, n, t) {
        "use strict";
        var a;
        t.d(n, "b", (function() {
            return o
        })), t.d(n, "c", (function() {
            return i
        })), t.d(n, "a", (function() {
            return a
        }));
        var o = function() {
                var e = this,
                    n = e.$createElement,
                    t = e._self._c || n;
                return t("App", {
                    attrs: {
                        keepAliveInclude: e.keepAliveInclude
                    }
                })
            },
            i = []
    },
    "32fa": function(e, n, t) {
        var a = t("24fb");
        n = a(!1), n.push([e.i, "\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n/*每个页面公共css */uni-page-body{background-color:#fff}body.?%PAGE?%{background-color:#fff}", ""]), e.exports = n
    },
    "49b6": function(e, n, t) {
        var a = t("32fa");
        "string" === typeof a && (a = [
            [e.i, a, ""]
        ]), a.locals && (e.exports = a.locals);
        var o = t("4f06")
            .default;
        o("451312fa", a, !0, {
            sourceMap: !1,
            shadowMode: !1
        })
    },
    5072: function(e, n, t) {
        "use strict";
        (function(e) {
            Object.defineProperty(n, "__esModule", {
                value: !0
            }), n.default = void 0;
            var t = {
                onLaunch: function(n) {
                    this.setHomepageurl(window.location.href), n.query.appid && client.setAppid(n.query.appid), n.query.vi && client.setVid(n.query.vi), e.log("App Launch")
                },
                onShow: function() {
                    e.log("App Show")
                },
                onHide: function() {
                    e.log("App Hide")
                }
            };
            n.default = t
        })
            .call(this, t("5a52")["default"])
    },
    "58cb": function(e, n, t) {
        "use strict";
        (function(e) {
            var a = t("4ea4");
            t("caad"), t("c975"), t("d3b7"), t("acd8"), t("4d63"), t("ac1f"), t("25f0"), t("5319"), t("841c"), t("1276"), t("498a"), Object.defineProperty(n, "__esModule", {
                value: !0
            }), n.default = void 0;
            var o = a(t("e9d6")),
                i = {
                    install: function(n, t) {
                        n.prototype.websiteName = "充值平台", n.prototype.timeFormat = function(e) {
                            var n = arguments[1] ? arguments[1] : "yyyy-MM-dd hh:mm:ss";
                            if (!e) return "";
                            var t = new Date;
                            10 == e.toString()
                                .length ? t.setTime(1e3 * e) : t.setTime(e);
                            var a = {
                                "M+": t.getMonth() + 1,
                                "d+": t.getDate(),
                                "h+": t.getHours(),
                                "m+": t.getMinutes(),
                                "s+": t.getSeconds(),
                                "q+": Math.floor((t.getMonth() + 3) / 3),
                                S: t.getMilliseconds()
                            };
                            for (var o in /(y+)/.test(n) && (n = n.replace(RegExp.$1, (t.getFullYear() + "")
                                .substr(4 - RegExp.$1.length))), a) new RegExp("(" + o + ")")
                                .test(n) && (n = n.replace(RegExp.$1, 1 == RegExp.$1.length ? a[o] : ("00" + a[o])
                                .substr(("" + a[o])
                                    .length)));
                            return n
                        }, n.prototype.strToTime = function(e) {
                            e = e.substring(0, 19), e = e.replace(/-/g, "/");
                            var n = new Date(e)
                                .getTime() / 1e3;
                            return isNaN(n) ? 0 : n
                        }, n.prototype.timestamp = function(e) {
                            return (new Date)
                                .getTime() / 1e3
                        }, n.prototype.GetUrlParame = function(n) {
                            var t = window.location.search;
                            if (e.log(t), t.indexOf(n) > -1) {
                                var a = "";
                                return a = t.substring(t.indexOf(n), t.length), a.indexOf("&") > -1 ? (a = a.substring(0, a.indexOf("&")), a = a.replace(n + "=", ""), a) : ""
                            }
                        }, n.prototype.toast = function(e) {
                            uni.showToast({
                                title: e,
                                icon: "none",
                                duration: 2e3
                            })
                        }, n.prototype.showLoading = function(e) {
                            uni.showLoading({
                                title: "加载中"
                            })
                        }, n.prototype.navigateTo = function(e) {
                            uni.navigateTo({
                                url: e
                            })
                        }, n.prototype.openH5Url = function(e) {
                            e && (window.location.href = e)
                        }, n.prototype.moneyFloat = function(e) {
                            e = parseFloat(e);
                            isNaN(e) && (e = 0), e = Math.round(100 * e) / 100;
                            var n = e.toString()
                                .split(".");
                            return 1 == n.length ? (e = e.toString() + ".00", e) : n.length > 1 ? (n[1].length < 2 && (e = e.toString() + "0"), e) : void 0
                        }, n.prototype.mobileFormat = function(e) {
                            var n = e.replace(/\s/g, "")
                                .replace(/(\d{3})(\d{0,4})(\d{0,4})/, "$1 $2 $3")
                                .replace(/\s+/g, " ");
                            return [3, 7].includes(e.replace(/\s/g, "")
                                .length) || (n = n.trim()), n
                        }, n.prototype.requestPayment = function(e, t) {
                            o.default.chooseWXPay({
                                timestamp: e.timeStamp + "",
                                nonceStr: e.nonceStr,
                                package: e.package,
                                signType: e.signType,
                                paySign: e.sign,
                                success: function(e) {
                                    "chooseWXPay:ok" == e.errMsg ? t({
                                        status: !0
                                    }) : t({
                                        status: !1
                                    })
                                },
                                cancel: function(a) {
                                    uni.showModal({
                                        title: "提示",
                                        content: "您确定要取消支付？",
                                        cancelText: "取消支付",
                                        confirmText: "继续支付",
                                        success: function(a) {
                                            a.confirm ? n.prototype.requestPayment(e, t) : a.cancel && (uni.showToast({
                                                title: "已取消支付",
                                                icon: "none"
                                            }), t({
                                                status: !1
                                            }))
                                        }
                                    })
                                },
                                fail: function(e) {
                                    t({
                                        status: !1
                                    })
                                }
                            })
                        }
                    }
                };
            n.default = i
        })
            .call(this, t("5a52")["default"])
    },
    "6d54": function(e, n, t) {
        "use strict";
        var a = t("49b6"),
            o = t.n(a);
        o.a
    },
    "7a86": function(e, n, t) {
        "use strict";
        t.r(n);
        var a = t("222c"),
            o = t("e673");
        for (var i in o) "default" !== i && function(e) {
            t.d(n, e, (function() {
                return o[e]
            }))
        }(i);
        t("6d54");
        var r, s = t("f0c5"),
            c = Object(s["a"])(o["default"], a["b"], a["c"], !1, null, null, null, !1, a["a"], r);
        n["default"] = c.exports
    },
    8588: function(e, n, t) {
        "use strict";
        (function(e) {
            var n = t("4ea4"),
                a = n(t("e143"));
            e["____8A89990____"] = !0, delete e["____8A89990____"], e.__uniConfig = {
                tabBar: {
                    color: "#7A7E83",
                    selectedColor: "#0d89eb",
                    backgroundColor: "#ffffff",
                    borderStyle: "black",
                    list: [{
                        pagePath: "pages/index/index",
                        iconPath: "static/tabbar/tab_icon11.png",
                        selectedIconPath: "static/tabbar/tab_icon10.png",
                        text: "充值1",
                        redDot: !1,
                        badge: ""
                    }, {
                        pagePath: "pages/my/my",
                        iconPath: "static/tabbar/tab_icon21.png",
                        selectedIconPath: "static/tabbar/tab_icon20.png",
                        text: "我的1",
                        redDot: !1,
                        badge: ""
                    }],
                    position: "bottom"
                },
                globalStyle: {
                    navigationBarTextStyle: "black",
                    navigationBarTitleText: "uni-app",
                    navigationBarBackgroundColor: "#F8F8F8",
                    backgroundColor: "#F8F8F8"
                }
            }, e.__uniConfig.compilerVersion = "3.1.22", e.__uniConfig.router = {
                mode: "hash",
                base: "/"
            }, e.__uniConfig.publicPath = "/", e.__uniConfig["async"] = {
                loading: "AsyncLoading",
                error: "AsyncError",
                delay: 200,
                timeout: 6e4
            }, e.__uniConfig.debug = !1, e.__uniConfig.networkTimeout = {
                request: 6e4,
                connectSocket: 6e4,
                uploadFile: 6e4,
                downloadFile: 6e4
            }, e.__uniConfig.sdkConfigs = {}, e.__uniConfig.qqMapKey = "XVXBZ-NDMC4-JOGUS-XGIEE-QVHDZ-AMFV2", e.__uniConfig.nvue = {
                "flex-direction": "column"
            }, e.__uniConfig.__webpack_chunk_load__ = t.e, a.default.component("pages-index-index", (function(e) {
                var n = {
                    component: Promise.all([t.e("pages-agent-lirun~pages-index-index~pages-my-apply~pages-my-my~pages-other-helps"), t.e("pages-index-index")])
                        .then(function() {
                            return e(t("55df"))
                        }.bind(null, t))
                        .catch(t.oe),
                    delay: __uniConfig["async"].delay,
                    timeout: __uniConfig["async"].timeout
                };
                return __uniConfig["async"]["loading"] && (n.loading = {
                    name: "SystemAsyncLoading",
                    render: function(e) {
                        return e(__uniConfig["async"]["loading"])
                    }
                }), __uniConfig["async"]["error"] && (n.error = {
                    name: "SystemAsyncError",
                    render: function(e) {
                        return e(__uniConfig["async"]["error"])
                    }
                }), n
            })), a.default.component("pages-index-paysus", (function(e) {
                var n = {
                    component: t.e("pages-index-paysus")
                        .then(function() {
                            return e(t("4c94"))
                        }.bind(null, t))
                        .catch(t.oe),
                    delay: __uniConfig["async"].delay,
                    timeout: __uniConfig["async"].timeout
                };
                return __uniConfig["async"]["loading"] && (n.loading = {
                    name: "SystemAsyncLoading",
                    render: function(e) {
                        return e(__uniConfig["async"]["loading"])
                    }
                }), __uniConfig["async"]["error"] && (n.error = {
                    name: "SystemAsyncError",
                    render: function(e) {
                        return e(__uniConfig["async"]["error"])
                    }
                }), n
            })), a.default.component("pages-login-oauth", (function(e) {
                var n = {
                    component: t.e("pages-login-oauth")
                        .then(function() {
                            return e(t("470d"))
                        }.bind(null, t))
                        .catch(t.oe),
                    delay: __uniConfig["async"].delay,
                    timeout: __uniConfig["async"].timeout
                };
                return __uniConfig["async"]["loading"] && (n.loading = {
                    name: "SystemAsyncLoading",
                    render: function(e) {
                        return e(__uniConfig["async"]["loading"])
                    }
                }), __uniConfig["async"]["error"] && (n.error = {
                    name: "SystemAsyncError",
                    render: function(e) {
                        return e(__uniConfig["async"]["error"])
                    }
                }), n
            })), a.default.component("pages-login-loginpwd", (function(e) {
                var n = {
                    component: t.e("pages-login-loginpwd")
                        .then(function() {
                            return e(t("398d"))
                        }.bind(null, t))
                        .catch(t.oe),
                    delay: __uniConfig["async"].delay,
                    timeout: __uniConfig["async"].timeout
                };
                return __uniConfig["async"]["loading"] && (n.loading = {
                    name: "SystemAsyncLoading",
                    render: function(e) {
                        return e(__uniConfig["async"]["loading"])
                    }
                }), __uniConfig["async"]["error"] && (n.error = {
                    name: "SystemAsyncError",
                    render: function(e) {
                        return e(__uniConfig["async"]["error"])
                    }
                }), n
            })), a.default.component("pages-my-my", (function(e) {
                var n = {
                    component: Promise.all([t.e("pages-agent-lirun~pages-index-index~pages-my-apply~pages-my-my~pages-other-helps"), t.e("pages-my-my")])
                        .then(function() {
                            return e(t("ae63"))
                        }.bind(null, t))
                        .catch(t.oe),
                    delay: __uniConfig["async"].delay,
                    timeout: __uniConfig["async"].timeout
                };
                return __uniConfig["async"]["loading"] && (n.loading = {
                    name: "SystemAsyncLoading",
                    render: function(e) {
                        return e(__uniConfig["async"]["loading"])
                    }
                }), __uniConfig["async"]["error"] && (n.error = {
                    name: "SystemAsyncError",
                    render: function(e) {
                        return e(__uniConfig["async"]["error"])
                    }
                }), n
            })), a.default.component("pages-my-apply", (function(e) {
                var n = {
                    component: Promise.all([t.e("pages-agent-lirun~pages-index-index~pages-my-apply~pages-my-my~pages-other-helps"), t.e("pages-my-apply")])
                        .then(function() {
                            return e(t("b5d3"))
                        }.bind(null, t))
                        .catch(t.oe),
                    delay: __uniConfig["async"].delay,
                    timeout: __uniConfig["async"].timeout
                };
                return __uniConfig["async"]["loading"] && (n.loading = {
                    name: "SystemAsyncLoading",
                    render: function(e) {
                        return e(__uniConfig["async"]["loading"])
                    }
                }), __uniConfig["async"]["error"] && (n.error = {
                    name: "SystemAsyncError",
                    render: function(e) {
                        return e(__uniConfig["async"]["error"])
                    }
                }), n
            })), a.default.component("pages-my-record", (function(e) {
                var n = {
                    component: Promise.all([t.e("pages-agent-balancelog~pages-agent-rebateorder~pages-agent-tixianlog~pages-my-record"), t.e("pages-my-record")])
                        .then(function() {
                            return e(t("9d9a"))
                        }.bind(null, t))
                        .catch(t.oe),
                    delay: __uniConfig["async"].delay,
                    timeout: __uniConfig["async"].timeout
                };
                return __uniConfig["async"]["loading"] && (n.loading = {
                    name: "SystemAsyncLoading",
                    render: function(e) {
                        return e(__uniConfig["async"]["loading"])
                    }
                }), __uniConfig["async"]["error"] && (n.error = {
                    name: "SystemAsyncError",
                    render: function(e) {
                        return e(__uniConfig["async"]["error"])
                    }
                }), n
            })), a.default.component("pages-other-helps", (function(e) {
                var n = {
                    component: Promise.all([t.e("pages-agent-lirun~pages-index-index~pages-my-apply~pages-my-my~pages-other-helps"), t.e("pages-other-helps")])
                        .then(function() {
                            return e(t("6f04"))
                        }.bind(null, t))
                        .catch(t.oe),
                    delay: __uniConfig["async"].delay,
                    timeout: __uniConfig["async"].timeout
                };
                return __uniConfig["async"]["loading"] && (n.loading = {
                    name: "SystemAsyncLoading",
                    render: function(e) {
                        return e(__uniConfig["async"]["loading"])
                    }
                }), __uniConfig["async"]["error"] && (n.error = {
                    name: "SystemAsyncError",
                    render: function(e) {
                        return e(__uniConfig["async"]["error"])
                    }
                }), n
            })), a.default.component("pages-agent-balance", (function(e) {
                var n = {
                    component: t.e("pages-agent-balance")
                        .then(function() {
                            return e(t("1113"))
                        }.bind(null, t))
                        .catch(t.oe),
                    delay: __uniConfig["async"].delay,
                    timeout: __uniConfig["async"].timeout
                };
                return __uniConfig["async"]["loading"] && (n.loading = {
                    name: "SystemAsyncLoading",
                    render: function(e) {
                        return e(__uniConfig["async"]["loading"])
                    }
                }), __uniConfig["async"]["error"] && (n.error = {
                    name: "SystemAsyncError",
                    render: function(e) {
                        return e(__uniConfig["async"]["error"])
                    }
                }), n
            })), a.default.component("pages-agent-balancelog", (function(e) {
                var n = {
                    component: Promise.all([t.e("pages-agent-balancelog~pages-agent-rebateorder~pages-agent-tixianlog~pages-my-record"), t.e("pages-agent-balancelog")])
                        .then(function() {
                            return e(t("2b16"))
                        }.bind(null, t))
                        .catch(t.oe),
                    delay: __uniConfig["async"].delay,
                    timeout: __uniConfig["async"].timeout
                };
                return __uniConfig["async"]["loading"] && (n.loading = {
                    name: "SystemAsyncLoading",
                    render: function(e) {
                        return e(__uniConfig["async"]["loading"])
                    }
                }), __uniConfig["async"]["error"] && (n.error = {
                    name: "SystemAsyncError",
                    render: function(e) {
                        return e(__uniConfig["async"]["error"])
                    }
                }), n
            })), a.default.component("pages-agent-yaoqinlog", (function(e) {
                var n = {
                    component: t.e("pages-agent-yaoqinlog")
                        .then(function() {
                            return e(t("d52f"))
                        }.bind(null, t))
                        .catch(t.oe),
                    delay: __uniConfig["async"].delay,
                    timeout: __uniConfig["async"].timeout
                };
                return __uniConfig["async"]["loading"] && (n.loading = {
                    name: "SystemAsyncLoading",
                    render: function(e) {
                        return e(__uniConfig["async"]["loading"])
                    }
                }), __uniConfig["async"]["error"] && (n.error = {
                    name: "SystemAsyncError",
                    render: function(e) {
                        return e(__uniConfig["async"]["error"])
                    }
                }), n
            })), a.default.component("pages-agent-poster", (function(e) {
                var n = {
                    component: t.e("pages-agent-poster")
                        .then(function() {
                            return e(t("c4bf"))
                        }.bind(null, t))
                        .catch(t.oe),
                    delay: __uniConfig["async"].delay,
                    timeout: __uniConfig["async"].timeout
                };
                return __uniConfig["async"]["loading"] && (n.loading = {
                    name: "SystemAsyncLoading",
                    render: function(e) {
                        return e(__uniConfig["async"]["loading"])
                    }
                }), __uniConfig["async"]["error"] && (n.error = {
                    name: "SystemAsyncError",
                    render: function(e) {
                        return e(__uniConfig["async"]["error"])
                    }
                }), n
            })), a.default.component("pages-agent-haibao", (function(e) {
                var n = {
                    component: t.e("pages-agent-haibao")
                        .then(function() {
                            return e(t("e57e"))
                        }.bind(null, t))
                        .catch(t.oe),
                    delay: __uniConfig["async"].delay,
                    timeout: __uniConfig["async"].timeout
                };
                return __uniConfig["async"]["loading"] && (n.loading = {
                    name: "SystemAsyncLoading",
                    render: function(e) {
                        return e(__uniConfig["async"]["loading"])
                    }
                }), __uniConfig["async"]["error"] && (n.error = {
                    name: "SystemAsyncError",
                    render: function(e) {
                        return e(__uniConfig["async"]["error"])
                    }
                }), n
            })), a.default.component("pages-agent-index", (function(e) {
                var n = {
                    component: t.e("pages-agent-index")
                        .then(function() {
                            return e(t("767a"))
                        }.bind(null, t))
                        .catch(t.oe),
                    delay: __uniConfig["async"].delay,
                    timeout: __uniConfig["async"].timeout
                };
                return __uniConfig["async"]["loading"] && (n.loading = {
                    name: "SystemAsyncLoading",
                    render: function(e) {
                        return e(__uniConfig["async"]["loading"])
                    }
                }), __uniConfig["async"]["error"] && (n.error = {
                    name: "SystemAsyncError",
                    render: function(e) {
                        return e(__uniConfig["async"]["error"])
                    }
                }), n
            })), a.default.component("pages-other-doc", (function(e) {
                var n = {
                    component: t.e("pages-other-doc")
                        .then(function() {
                            return e(t("c1fe"))
                        }.bind(null, t))
                        .catch(t.oe),
                    delay: __uniConfig["async"].delay,
                    timeout: __uniConfig["async"].timeout
                };
                return __uniConfig["async"]["loading"] && (n.loading = {
                    name: "SystemAsyncLoading",
                    render: function(e) {
                        return e(__uniConfig["async"]["loading"])
                    }
                }), __uniConfig["async"]["error"] && (n.error = {
                    name: "SystemAsyncError",
                    render: function(e) {
                        return e(__uniConfig["async"]["error"])
                    }
                }), n
            })), a.default.component("pages-other-tagline", (function(e) {
                var n = {
                    component: t.e("pages-other-tagline")
                        .then(function() {
                            return e(t("21c0"))
                        }.bind(null, t))
                        .catch(t.oe),
                    delay: __uniConfig["async"].delay,
                    timeout: __uniConfig["async"].timeout
                };
                return __uniConfig["async"]["loading"] && (n.loading = {
                    name: "SystemAsyncLoading",
                    render: function(e) {
                        return e(__uniConfig["async"]["loading"])
                    }
                }), __uniConfig["async"]["error"] && (n.error = {
                    name: "SystemAsyncError",
                    render: function(e) {
                        return e(__uniConfig["async"]["error"])
                    }
                }), n
            })), a.default.component("pages-agent-links", (function(e) {
                var n = {
                    component: t.e("pages-agent-links")
                        .then(function() {
                            return e(t("7d4c"))
                        }.bind(null, t))
                        .catch(t.oe),
                    delay: __uniConfig["async"].delay,
                    timeout: __uniConfig["async"].timeout
                };
                return __uniConfig["async"]["loading"] && (n.loading = {
                    name: "SystemAsyncLoading",
                    render: function(e) {
                        return e(__uniConfig["async"]["loading"])
                    }
                }), __uniConfig["async"]["error"] && (n.error = {
                    name: "SystemAsyncError",
                    render: function(e) {
                        return e(__uniConfig["async"]["error"])
                    }
                }), n
            })), a.default.component("pages-agent-tixianlog", (function(e) {
                var n = {
                    component: Promise.all([t.e("pages-agent-balancelog~pages-agent-rebateorder~pages-agent-tixianlog~pages-my-record"), t.e("pages-agent-tixianlog")])
                        .then(function() {
                            return e(t("90d6"))
                        }.bind(null, t))
                        .catch(t.oe),
                    delay: __uniConfig["async"].delay,
                    timeout: __uniConfig["async"].timeout
                };
                return __uniConfig["async"]["loading"] && (n.loading = {
                    name: "SystemAsyncLoading",
                    render: function(e) {
                        return e(__uniConfig["async"]["loading"])
                    }
                }), __uniConfig["async"]["error"] && (n.error = {
                    name: "SystemAsyncError",
                    render: function(e) {
                        return e(__uniConfig["async"]["error"])
                    }
                }), n
            })), a.default.component("pages-agent-rebateorder", (function(e) {
                var n = {
                    component: Promise.all([t.e("pages-agent-balancelog~pages-agent-rebateorder~pages-agent-tixianlog~pages-my-record"), t.e("pages-agent-rebateorder")])
                        .then(function() {
                            return e(t("258a"))
                        }.bind(null, t))
                        .catch(t.oe),
                    delay: __uniConfig["async"].delay,
                    timeout: __uniConfig["async"].timeout
                };
                return __uniConfig["async"]["loading"] && (n.loading = {
                    name: "SystemAsyncLoading",
                    render: function(e) {
                        return e(__uniConfig["async"]["loading"])
                    }
                }), __uniConfig["async"]["error"] && (n.error = {
                    name: "SystemAsyncError",
                    render: function(e) {
                        return e(__uniConfig["async"]["error"])
                    }
                }), n
            })), a.default.component("pages-agent-lirun", (function(e) {
                var n = {
                    component: Promise.all([t.e("pages-agent-lirun~pages-index-index~pages-my-apply~pages-my-my~pages-other-helps"), t.e("pages-agent-lirun")])
                        .then(function() {
                            return e(t("bdc5"))
                        }.bind(null, t))
                        .catch(t.oe),
                    delay: __uniConfig["async"].delay,
                    timeout: __uniConfig["async"].timeout
                };
                return __uniConfig["async"]["loading"] && (n.loading = {
                    name: "SystemAsyncLoading",
                    render: function(e) {
                        return e(__uniConfig["async"]["loading"])
                    }
                }), __uniConfig["async"]["error"] && (n.error = {
                    name: "SystemAsyncError",
                    render: function(e) {
                        return e(__uniConfig["async"]["error"])
                    }
                }), n
            })), e.__uniRoutes = [{
                path: "/",
                alias: "/pages/index/index",
                component: {
                    render: function(e) {
                        return e("Page", {
                            props: Object.assign({
                                isQuit: !0,
                                isEntry: !0,
                                isTabBar: !0,
                                tabBarIndex: 0
                            }, __uniConfig.globalStyle, {
                                navigationBarTitleText: "充值",
                                navigationStyle: "custom"
                            })
                        }, [e("pages-index-index", {
                            slot: "page"
                        })])
                    }
                },
                meta: {
                    id: 1,
                    name: "pages-index-index",
                    isNVue: !1,
                    maxWidth: 0,
                    pagePath: "pages/index/index",
                    isQuit: !0,
                    isEntry: !0,
                    isTabBar: !0,
                    tabBarIndex: 0,
                    windowTop: 0
                }
            }, {
                path: "/pages/index/paysus",
                component: {
                    render: function(e) {
                        return e("Page", {
                            props: Object.assign({}, __uniConfig.globalStyle, {
                                navigationBarTitleText: "支付成功"
                            })
                        }, [e("pages-index-paysus", {
                            slot: "page"
                        })])
                    }
                },
                meta: {
                    name: "pages-index-paysus",
                    isNVue: !1,
                    maxWidth: 0,
                    pagePath: "pages/index/paysus",
                    windowTop: 44
                }
            }, {
                path: "/pages/login/oauth",
                component: {
                    render: function(e) {
                        return e("Page", {
                            props: Object.assign({}, __uniConfig.globalStyle, {
                                navigationBarTitleText: "微信授权中",
                                navigationStyle: "custom"
                            })
                        }, [e("pages-login-oauth", {
                            slot: "page"
                        })])
                    }
                },
                meta: {
                    name: "pages-login-oauth",
                    isNVue: !1,
                    maxWidth: 0,
                    pagePath: "pages/login/oauth",
                    windowTop: 0
                }
            }, {
                path: "/pages/login/loginpwd",
                component: {
                    render: function(e) {
                        return e("Page", {
                            props: Object.assign({}, __uniConfig.globalStyle, {
                                navigationBarTitleText: "登录",
                                navigationStyle: "custom"
                            })
                        }, [e("pages-login-loginpwd", {
                            slot: "page"
                        })])
                    }
                },
                meta: {
                    name: "pages-login-loginpwd",
                    isNVue: !1,
                    maxWidth: 0,
                    pagePath: "pages/login/loginpwd",
                    windowTop: 0
                }
            }, {
                path: "/pages/my/my",
                component: {
                    render: function(e) {
                        return e("Page", {
                            props: Object.assign({
                                isQuit: !0,
                                isTabBar: !0,
                                tabBarIndex: 1
                            }, __uniConfig.globalStyle, {
                                navigationBarTitleText: "我的",
                                navigationStyle: "custom"
                            })
                        }, [e("pages-my-my", {
                            slot: "page"
                        })])
                    }
                },
                meta: {
                    id: 2,
                    name: "pages-my-my",
                    isNVue: !1,
                    maxWidth: 0,
                    pagePath: "pages/my/my",
                    isQuit: !0,
                    isTabBar: !0,
                    tabBarIndex: 1,
                    windowTop: 0
                }
            }, {
                path: "/pages/my/apply",
                component: {
                    render: function(e) {
                        return e("Page", {
                            props: Object.assign({}, __uniConfig.globalStyle, {
                                navigationBarTitleText: "升级代理",
                                navigationStyle: "custom"
                            })
                        }, [e("pages-my-apply", {
                            slot: "page"
                        })])
                    }
                },
                meta: {
                    name: "pages-my-apply",
                    isNVue: !1,
                    maxWidth: 0,
                    pagePath: "pages/my/apply",
                    windowTop: 0
                }
            }, {
                path: "/pages/my/record",
                component: {
                    render: function(e) {
                        return e("Page", {
                            props: Object.assign({}, __uniConfig.globalStyle, {
                                navigationBarTitleText: "充值记录",
                                navigationStyle: "custom"
                            })
                        }, [e("pages-my-record", {
                            slot: "page"
                        })])
                    }
                },
                meta: {
                    name: "pages-my-record",
                    isNVue: !1,
                    maxWidth: 0,
                    pagePath: "pages/my/record",
                    windowTop: 0
                }
            }, {
                path: "/pages/other/helps",
                component: {
                    render: function(e) {
                        return e("Page", {
                            props: Object.assign({}, __uniConfig.globalStyle, {
                                navigationBarTitleText: "客服帮助",
                                navigationStyle: "custom"
                            })
                        }, [e("pages-other-helps", {
                            slot: "page"
                        })])
                    }
                },
                meta: {
                    name: "pages-other-helps",
                    isNVue: !1,
                    maxWidth: 0,
                    pagePath: "pages/other/helps",
                    windowTop: 0
                }
            }, {
                path: "/pages/agent/balance",
                component: {
                    render: function(e) {
                        return e("Page", {
                            props: Object.assign({}, __uniConfig.globalStyle, {
                                navigationBarTitleText: "余额",
                                navigationStyle: "custom"
                            })
                        }, [e("pages-agent-balance", {
                            slot: "page"
                        })])
                    }
                },
                meta: {
                    name: "pages-agent-balance",
                    isNVue: !1,
                    maxWidth: 0,
                    pagePath: "pages/agent/balance",
                    windowTop: 0
                }
            }, {
                path: "/pages/agent/balancelog",
                component: {
                    render: function(e) {
                        return e("Page", {
                            props: Object.assign({}, __uniConfig.globalStyle, {
                                navigationBarTitleText: "余额日志",
                                navigationStyle: "custom"
                            })
                        }, [e("pages-agent-balancelog", {
                            slot: "page"
                        })])
                    }
                },
                meta: {
                    name: "pages-agent-balancelog",
                    isNVue: !1,
                    maxWidth: 0,
                    pagePath: "pages/agent/balancelog",
                    windowTop: 0
                }
            }, {
                path: "/pages/agent/yaoqinlog",
                component: {
                    render: function(e) {
                        return e("Page", {
                            props: Object.assign({}, __uniConfig.globalStyle, {
                                navigationBarTitleText: "代理中心",
                                navigationStyle: "custom"
                            })
                        }, [e("pages-agent-yaoqinlog", {
                            slot: "page"
                        })])
                    }
                },
                meta: {
                    name: "pages-agent-yaoqinlog",
                    isNVue: !1,
                    maxWidth: 0,
                    pagePath: "pages/agent/yaoqinlog",
                    windowTop: 0
                }
            }, {
                path: "/pages/agent/poster",
                component: {
                    render: function(e) {
                        return e("Page", {
                            props: Object.assign({}, __uniConfig.globalStyle, {
                                navigationBarTitleText: "二维码",
                                navigationStyle: "custom"
                            })
                        }, [e("pages-agent-poster", {
                            slot: "page"
                        })])
                    }
                },
                meta: {
                    name: "pages-agent-poster",
                    isNVue: !1,
                    maxWidth: 0,
                    pagePath: "pages/agent/poster",
                    windowTop: 0
                }
            }, {
                path: "/pages/agent/haibao",
                component: {
                    render: function(e) {
                        return e("Page", {
                            props: Object.assign({}, __uniConfig.globalStyle, {
                                navigationBarTitleText: "二维码",
                                navigationStyle: "custom"
                            })
                        }, [e("pages-agent-haibao", {
                            slot: "page"
                        })])
                    }
                },
                meta: {
                    name: "pages-agent-haibao",
                    isNVue: !1,
                    maxWidth: 0,
                    pagePath: "pages/agent/haibao",
                    windowTop: 0
                }
            }, {
                path: "/pages/agent/index",
                component: {
                    render: function(e) {
                        return e("Page", {
                            props: Object.assign({}, __uniConfig.globalStyle, {
                                navigationBarTitleText: "充值",
                                navigationStyle: "custom"
                            })
                        }, [e("pages-agent-index", {
                            slot: "page"
                        })])
                    }
                },
                meta: {
                    name: "pages-agent-index",
                    isNVue: !1,
                    maxWidth: 0,
                    pagePath: "pages/agent/index",
                    windowTop: 0
                }
            }, {
                path: "/pages/other/doc",
                component: {
                    render: function(e) {
                        return e("Page", {
                            props: Object.assign({}, __uniConfig.globalStyle, {
                                navigationBarTitleText: "文档",
                                navigationStyle: "custom"
                            })
                        }, [e("pages-other-doc", {
                            slot: "page"
                        })])
                    }
                },
                meta: {
                    name: "pages-other-doc",
                    isNVue: !1,
                    maxWidth: 0,
                    pagePath: "pages/other/doc",
                    windowTop: 0
                }
            }, {
                path: "/pages/other/tagline",
                component: {
                    render: function(e) {
                        return e("Page", {
                            props: Object.assign({}, __uniConfig.globalStyle, {
                                navigationBarTitleText: "宣传语",
                                navigationStyle: "custom"
                            })
                        }, [e("pages-other-tagline", {
                            slot: "page"
                        })])
                    }
                },
                meta: {
                    name: "pages-other-tagline",
                    isNVue: !1,
                    maxWidth: 0,
                    pagePath: "pages/other/tagline",
                    windowTop: 0
                }
            }, {
                path: "/pages/agent/links",
                component: {
                    render: function(e) {
                        return e("Page", {
                            props: Object.assign({}, __uniConfig.globalStyle, {
                                navigationBarTitleText: "推广链接",
                                navigationStyle: "custom"
                            })
                        }, [e("pages-agent-links", {
                            slot: "page"
                        })])
                    }
                },
                meta: {
                    name: "pages-agent-links",
                    isNVue: !1,
                    maxWidth: 0,
                    pagePath: "pages/agent/links",
                    windowTop: 0
                }
            }, {
                path: "/pages/agent/tixianlog",
                component: {
                    render: function(e) {
                        return e("Page", {
                            props: Object.assign({}, __uniConfig.globalStyle, {
                                navigationBarTitleText: "提现记录",
                                navigationStyle: "custom"
                            })
                        }, [e("pages-agent-tixianlog", {
                            slot: "page"
                        })])
                    }
                },
                meta: {
                    name: "pages-agent-tixianlog",
                    isNVue: !1,
                    maxWidth: 0,
                    pagePath: "pages/agent/tixianlog",
                    windowTop: 0
                }
            }, {
                path: "/pages/agent/rebateorder",
                component: {
                    render: function(e) {
                        return e("Page", {
                            props: Object.assign({}, __uniConfig.globalStyle, {
                                navigationBarTitleText: "返利订单",
                                navigationStyle: "custom"
                            })
                        }, [e("pages-agent-rebateorder", {
                            slot: "page"
                        })])
                    }
                },
                meta: {
                    name: "pages-agent-rebateorder",
                    isNVue: !1,
                    maxWidth: 0,
                    pagePath: "pages/agent/rebateorder",
                    windowTop: 0
                }
            }, {
                path: "/pages/agent/lirun",
                component: {
                    render: function(e) {
                        return e("Page", {
                            props: Object.assign({}, __uniConfig.globalStyle, {
                                navigationBarTitleText: "利润设置",
                                navigationStyle: "custom"
                            })
                        }, [e("pages-agent-lirun", {
                            slot: "page"
                        })])
                    }
                },
                meta: {
                    name: "pages-agent-lirun",
                    isNVue: !1,
                    maxWidth: 0,
                    pagePath: "pages/agent/lirun",
                    windowTop: 0
                }
            }, {
                path: "/preview-image",
                component: {
                    render: function(e) {
                        return e("Page", {
                            props: {
                                navigationStyle: "custom"
                            }
                        }, [e("system-preview-image", {
                            slot: "page"
                        })])
                    }
                },
                meta: {
                    name: "preview-image",
                    pagePath: "/preview-image"
                }
            }, {
                path: "/choose-location",
                component: {
                    render: function(e) {
                        return e("Page", {
                            props: {
                                navigationStyle: "custom"
                            }
                        }, [e("system-choose-location", {
                            slot: "page"
                        })])
                    }
                },
                meta: {
                    name: "choose-location",
                    pagePath: "/choose-location"
                }
            }, {
                path: "/open-location",
                component: {
                    render: function(e) {
                        return e("Page", {
                            props: {
                                navigationStyle: "custom"
                            }
                        }, [e("system-open-location", {
                            slot: "page"
                        })])
                    }
                },
                meta: {
                    name: "open-location",
                    pagePath: "/open-location"
                }
            }], e.UniApp && new e.UniApp
        })
            .call(this, t("c8ba"))
    },
    ad09: function(e, n, t) {
        t("c975");
        var a = function() {
                var e = document.location.protocol + "//" + window.location.hostname + "/api.php/";
                return e
            },
            o = function(e) {
                return uni.setStorageSync("wx_appid", e), e
            },
            i = function() {
                var e = uni.getStorageSync("wx_appid") || "wx158a479a72a5b0dc";
                return e
            },
            r = function(e) {
                return uni.setStorageSync("token_" + i(), e), e
            },
            s = function(e) {
                var n = uni.getStorageSync("token_" + i()) || "";
                return n
            },
            c = function(e) {
                return uni.setStorageSync("vid_" + i(), e), e
            },
            u = function(e) {
                var n = uni.getStorageSync("vid_" + i()) || "";
                return n
            },
            g = function() {
                return 1
            },
            p = function() {
                var e = navigator.userAgent.toLowerCase(),
                    n = -1 != e.indexOf("micromessenger");
                return !!n
            },
            l = function() {
                return "https:" == document.location.protocol ? "https" : "http"
            };
        e.exports = {
            getApiurl: a,
            setAppid: o,
            getAppid: i,
            setToken: r,
            getToken: s,
            setVid: c,
            getVid: u,
            getClientType: g,
            isWeixinH5: p,
            getHttpProtocol: l
        }
    },
    d065: function(e, n, t) {
        "use strict";
        var a = t("4ea4"),
            o = a(t("e143")),
            i = a(t("d5dc")),
            r = a(t("ad09"));
        i.default.setConfig({
            baseUrl: "",
            dataType: "json",
            responseType: "text",
            header: {
                "Content-Type": "application/json;charset=utf-8"
            }
        }), i.default.interceptors.request((function(e) {
            return e.baseUrl = r.default.getApiurl(), e.header.Authorization = r.default.getToken(), e.header.Client = r.default.getClientType(), e.header.Appid = r.default.getAppid(), e
        })), i.default.interceptors.response((function(e) {
            if ("request:fail" != e.errMsg) return -1 == e.data.errno ? (alert("x"), void uni.reLaunch({
                url: "/pages/login/oauth"
            })) : e;
            uni.showToast({
                title: "网络开小差了",
                icon: "none",
                duration: 2e3
            })
        })), o.default.prototype.$request = i.default, e.exports = {
            request: i.default
        }
    },
    d5dc: function(e, n, t) {
        "use strict";
        (function(e, a) {
            var o = t("4ea4");
            t("b64b"), t("d3b7"), t("25f0"), t("8a79"), t("2ca0"), Object.defineProperty(n, "__esModule", {
                value: !0
            }), n.default = void 0, t("96cf");
            var i = o(t("1da1")),
                r = o(t("d4ec")),
                s = o(t("bee2")),
                c = function() {
                    function e() {
                        var n = this,
                            t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
                        (0, r.default)(this, e), this.config = {}, this.config.baseUrl = t.baseUrl ? t.baseUrl : "", this.config.dataType = t.dataType ? t.dataType : "json", this.config.responseType = t.responseType ? t.responseType : "text", this.config.header = t.header ? t.header : {}, this.reqInterceptors = null, this.resInterceptors = null, this.interceptors = {
                            request: function(e) {
                                n.reqInterceptors = e
                            },
                            response: function(e) {
                                n.resInterceptors = e
                            }
                        }
                    }
                    return (0, s.default)(e, [{
                        key: "get",
                        value: function() {
                            var e = (0, i.default)(regeneratorRuntime.mark((function e(n) {
                                var t, a = arguments;
                                return regeneratorRuntime.wrap((function(e) {
                                    while (1) switch (e.prev = e.next) {
                                        case 0:
                                            return t = a.length > 1 && void 0 !== a[1] ? a[1] : {}, e.abrupt("return", this._request("get", n, t));
                                        case 2:
                                        case "end":
                                            return e.stop()
                                    }
                                }), e, this)
                            })));

                            function n(n) {
                                return e.apply(this, arguments)
                            }
                            return n
                        }()
                    }, {
                        key: "post",
                        value: function() {
                            var e = (0, i.default)(regeneratorRuntime.mark((function e(n) {
                                var t, a = arguments;
                                return regeneratorRuntime.wrap((function(e) {
                                    while (1) switch (e.prev = e.next) {
                                        case 0:
                                            return t = a.length > 1 && void 0 !== a[1] ? a[1] : {}, e.abrupt("return", this._request("post", n, t));
                                        case 2:
                                        case "end":
                                            return e.stop()
                                    }
                                }), e, this)
                            })));

                            function n(n) {
                                return e.apply(this, arguments)
                            }
                            return n
                        }()
                    }, {
                        key: "put",
                        value: function() {
                            var e = (0, i.default)(regeneratorRuntime.mark((function e(n) {
                                var t, a = arguments;
                                return regeneratorRuntime.wrap((function(e) {
                                    while (1) switch (e.prev = e.next) {
                                        case 0:
                                            return t = a.length > 1 && void 0 !== a[1] ? a[1] : {}, e.abrupt("return", this._request("put", n, t));
                                        case 2:
                                        case "end":
                                            return e.stop()
                                    }
                                }), e, this)
                            })));

                            function n(n) {
                                return e.apply(this, arguments)
                            }
                            return n
                        }()
                    }, {
                        key: "delete",
                        value: function() {
                            var e = (0, i.default)(regeneratorRuntime.mark((function e(n) {
                                var t, a = arguments;
                                return regeneratorRuntime.wrap((function(e) {
                                    while (1) switch (e.prev = e.next) {
                                        case 0:
                                            return t = a.length > 1 && void 0 !== a[1] ? a[1] : {}, e.abrupt("return", this._request("delete", n, t));
                                        case 2:
                                        case "end":
                                            return e.stop()
                                    }
                                }), e, this)
                            })));

                            function n(n) {
                                return e.apply(this, arguments)
                            }
                            return n
                        }()
                    }, {
                        key: "setConfig",
                        value: function() {
                            var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
                            this.config = this._deepCopy(this._merge(this.config, e))
                        }
                    }, {
                        key: "getConfig",
                        value: function() {
                            return this.config
                        }
                    }, {
                        key: "_request",
                        value: function(e, n, t) {
                            var a = this,
                                o = this._deepCopy(this._merge(this.config, t)),
                                r = {};
                            if (this.reqInterceptors && "function" === typeof this.reqInterceptors) {
                                var s = this.reqInterceptors(o);
                                if ("[object Promise]" === Object.prototype.toString.call(s)) return s;
                                r = this._deepCopy(s)
                            } else r = this._deepCopy(o);
                            var c = this._formatUrl(r.baseUrl, n);
                            return new Promise((function(n, t) {
                                uni.request({
                                    url: c,
                                    method: e,
                                    data: r.data ? r.data : {},
                                    header: r.header,
                                    dataType: r.dataType,
                                    responseType: r.responseType,
                                    complete: function(e) {
                                        return (0, i.default)(regeneratorRuntime.mark((function o() {
                                            var i, r, s;
                                            return regeneratorRuntime.wrap((function(o) {
                                                while (1) switch (o.prev = o.next) {
                                                    case 0:
                                                        if (i = e, !a.resInterceptors || "function" !== typeof a.resInterceptors) {
                                                            o.next = 22;
                                                            break
                                                        }
                                                        if (r = a.resInterceptors(i), r) {
                                                            o.next = 8;
                                                            break
                                                        }
                                                        return t("返回值已被您拦截！"), o.abrupt("return");
                                                    case 8:
                                                        if ("[object Promise]" !== Object.prototype.toString.call(r)) {
                                                            o.next = 21;
                                                            break
                                                        }
                                                        return o.prev = 9, o.next = 12, r;
                                                    case 12:
                                                        s = o.sent, n(s), o.next = 19;
                                                        break;
                                                    case 16:
                                                        o.prev = 16, o.t0 = o["catch"](9), t(o.t0);
                                                    case 19:
                                                        o.next = 22;
                                                        break;
                                                    case 21:
                                                        i = r;
                                                    case 22:
                                                        n(i);
                                                    case 23:
                                                    case "end":
                                                        return o.stop()
                                                }
                                            }), o, null, [
                                                [9, 16]
                                            ])
                                        })))()
                                    }
                                })
                            }))
                        }
                    }, {
                        key: "_formatUrl",
                        value: function(e, n) {
                            if (!e) return n;
                            var t = "",
                                a = e.endsWith("/"),
                                o = n.startsWith("/");
                            return t = a && o ? e + n.substring(1) : a || o ? e + n : e + "/" + n, t
                        }
                    }, {
                        key: "_merge",
                        value: function(e, n) {
                            var t = this._deepCopy(e);
                            if (!n || !Object.keys(n)
                                .length) return t;
                            for (var a in n)
                                if ("header" !== a) t[a] = n[a];
                                else if ("[object Object]" === Object.prototype.toString.call(n[a]))
                                    for (var o in n[a]) t[a][o] = n[a][o];
                            return t
                        }
                    }, {
                        key: "_deepCopy",
                        value: function(e) {
                            var n = Array.isArray(e) ? [] : {};
                            for (var t in e) e.hasOwnProperty(t) && ("object" === typeof e[t] ? n[t] = this._deepCopy(e[t]) : n[t] = e[t]);
                            return n
                        }
                    }]), e
                }();
            a.$request || (a.$request = new c);
            var u = a.$request;
            n.default = u
        })
            .call(this, t("5a52")["default"], t("c8ba"))
    },
    e673: function(e, n, t) {
        "use strict";
        t.r(n);
        var a = t("5072"),
            o = t.n(a);
        for (var i in a) "default" !== i && function(e) {
            t.d(n, e, (function() {
                return a[e]
            }))
        }(i);
        n["default"] = o.a
    },
    e9d6: function(e, n, t) {
        (function(n) {
            t("c975"), t("ac1f"), t("466d"), t("5319"), t("1276");
            var a = t("9523");
            ! function(n, t) {
                e.exports = t(n)
            }(window, (function(e, t) {
                function o(n, t, a) {
                    e.WeixinJSBridge ? WeixinJSBridge.invoke(n, r(t), (function(e) {
                        u(n, e, a)
                    })) : l(n, a)
                }

                function i(n, t, a) {
                    e.WeixinJSBridge ? WeixinJSBridge.on(n, (function(e) {
                        a && a.trigger && a.trigger(e), u(n, e, t)
                    })) : l(n, a || t)
                }

                function r(e) {
                    return e = e || {}, e.appId = B.appId, e.verifyAppId = B.appId, e.verifySignType = "sha1", e.verifyTimestamp = B.timestamp + "", e.verifyNonceStr = B.nonceStr, e.verifySignature = B.signature, e
                }

                function s(e) {
                    return {
                        timeStamp: e.timestamp + "",
                        nonceStr: e.nonceStr,
                        package: e.package,
                        paySign: e.paySign,
                        signType: e.signType || "SHA1"
                    }
                }

                function c(e) {
                    return e.postalCode = e.addressPostalCode, delete e.addressPostalCode, e.provinceName = e.proviceFirstStageName, delete e.proviceFirstStageName, e.cityName = e.addressCitySecondStageName, delete e.addressCitySecondStageName, e.countryName = e.addressCountiesThirdStageName, delete e.addressCountiesThirdStageName, e.detailInfo = e.addressDetailInfo, delete e.addressDetailInfo, e
                }

                function u(e, n, t) {
                    "openEnterpriseChat" == e && (n.errCode = n.err_code), delete n.err_code, delete n.err_desc, delete n.err_detail;
                    var a = n.errMsg;
                    a || (a = n.err_msg, delete n.err_msg, a = g(e, a), n.errMsg = a), (t = t || {})
                        ._complete && (t._complete(n), delete t._complete), a = n.errMsg || "", B.debug && !t.isInnerInvoke && alert(JSON.stringify(n));
                    var o = a.indexOf(":");
                    switch (a.substring(o + 1)) {
                        case "ok":
                            t.success && t.success(n);
                            break;
                        case "cancel":
                            t.cancel && t.cancel(n);
                            break;
                        default:
                            t.fail && t.fail(n)
                    }
                    t.complete && t.complete(n)
                }

                function g(e, n) {
                    var t = e,
                        a = b[t];
                    a && (t = a);
                    var o = "ok";
                    if (n) {
                        var i = n.indexOf(":");
                        "confirm" == (o = n.substring(i + 1)) && (o = "ok"), "failed" == o && (o = "fail"), -1 != o.indexOf("failed_") && (o = o.substring(7)), -1 != o.indexOf("fail_") && (o = o.substring(5)), "access denied" != (o = (o = o.replace(/_/g, " "))
                            .toLowerCase()) && "no permission to execute" != o || (o = "permission denied"), "config" == t && "function not exist" == o && (o = "ok"), "" == o && (o = "fail")
                    }
                    return t + ":" + o
                }

                function p(e) {
                    if (e) {
                        for (var n = 0, t = e.length; n < t; ++n) {
                            var a = e[n],
                                o = v[a];
                            o && (e[n] = o)
                        }
                        return e
                    }
                }

                function l(e, t) {
                    if (!(!B.debug || t && t.isInnerInvoke)) {
                        var a = b[e];
                        a && (e = a), t && t._complete && delete t._complete, n.log('"' + e + '",', t || "")
                    }
                }

                function d(e) {
                    if (!(T || P || B.debug || M < "6.0.2" || V.systemType < 0)) {
                        var n = new Image;
                        V.appId = B.appId, V.initTime = O.initEndTime - O.initStartTime, V.preVerifyTime = O.preVerifyEndTime - O.preVerifyStartTime, W.getNetworkType({
                            isInnerInvoke: !0,
                            success: function(e) {
                                V.networkType = e.networkType;
                                var t = "https://open.weixin.qq.com/sdk/report?v=" + V.version + "&o=" + V.isPreVerifyOk + "&s=" + V.systemType + "&c=" + V.clientVersion + "&a=" + V.appId + "&n=" + V.networkType + "&i=" + V.initTime + "&p=" + V.preVerifyTime + "&u=" + V.url;
                                n.src = t
                            }
                        })
                    }
                }

                function f() {
                    return (new Date)
                        .getTime()
                }

                function m(n) {
                    k && (e.WeixinJSBridge ? n() : S.addEventListener && S.addEventListener("WeixinJSBridgeReady", n, !1))
                }

                function y() {
                    W.invoke || (W.invoke = function(n, t, a) {
                        e.WeixinJSBridge && WeixinJSBridge.invoke(n, r(t), a)
                    }, W.on = function(n, t) {
                        e.WeixinJSBridge && WeixinJSBridge.on(n, t)
                    })
                }

                function h(e) {
                    if ("string" == typeof e && e.length > 0) {
                        var n = e.split("?")[0],
                            t = e.split("?")[1];
                        return n += ".html", void 0 !== t ? n + "?" + t : n
                    }
                }
                if (!e.jWeixin) {
                    var _, v = {
                            config: "preVerifyJSAPI",
                            onMenuShareTimeline: "menu:share:timeline",
                            onMenuShareAppMessage: "menu:share:appmessage",
                            onMenuShareQQ: "menu:share:qq",
                            onMenuShareWeibo: "menu:share:weiboApp",
                            onMenuShareQZone: "menu:share:QZone",
                            previewImage: "imagePreview",
                            getLocation: "geoLocation",
                            openProductSpecificView: "openProductViewWithPid",
                            addCard: "batchAddCard",
                            openCard: "batchViewCard",
                            chooseWXPay: "getBrandWCPayRequest",
                            openEnterpriseRedPacket: "getRecevieBizHongBaoRequest",
                            startSearchBeacons: "startMonitoringBeacons",
                            stopSearchBeacons: "stopMonitoringBeacons",
                            onSearchBeacons: "onBeaconsInRange",
                            consumeAndShareCard: "consumedShareCard",
                            openAddress: "editAddress"
                        },
                        b = function() {
                            var e = {};
                            for (var n in v) e[v[n]] = n;
                            return e
                        }(),
                        S = e.document,
                        C = S.title,
                        x = navigator.userAgent.toLowerCase(),
                        w = navigator.platform.toLowerCase(),
                        T = !(!w.match("mac") && !w.match("win")),
                        P = -1 != x.indexOf("wxdebugger"),
                        k = -1 != x.indexOf("micromessenger"),
                        I = -1 != x.indexOf("android"),
                        A = -1 != x.indexOf("iphone") || -1 != x.indexOf("ipad"),
                        M = function() {
                            var e = x.match(/micromessenger\/(\d+\.\d+\.\d+)/) || x.match(/micromessenger\/(\d+\.\d+)/);
                            return e ? e[1] : ""
                        }(),
                        O = {
                            initStartTime: f(),
                            initEndTime: 0,
                            preVerifyStartTime: 0,
                            preVerifyEndTime: 0
                        },
                        V = {
                            version: 1,
                            appId: "",
                            initTime: 0,
                            preVerifyTime: 0,
                            networkType: "",
                            isPreVerifyOk: 1,
                            systemType: A ? 1 : I ? 2 : -1,
                            clientVersion: M,
                            url: encodeURIComponent(location.href)
                        },
                        B = {},
                        E = {
                            _completes: []
                        },
                        L = {
                            state: 0,
                            data: {}
                        };
                    m((function() {
                        O.initEndTime = f()
                    }));
                    var N = !1,
                        j = [],
                        W = (_ = {
                            config: function(e) {
                                B = e, l("config", e);
                                var n = !1 !== B.check;
                                m((function() {
                                    if (n) o(v.config, {
                                        verifyJsApiList: p(B.jsApiList)
                                    }, function() {
                                        E._complete = function(e) {
                                            O.preVerifyEndTime = f(), L.state = 1, L.data = e
                                        }, E.success = function(e) {
                                            V.isPreVerifyOk = 0
                                        }, E.fail = function(e) {
                                            E._fail ? E._fail(e) : L.state = -1
                                        };
                                        var e = E._completes;
                                        return e.push((function() {
                                            d()
                                        })), E.complete = function(n) {
                                            for (var t = 0, a = e.length; t < a; ++t) e[t]();
                                            E._completes = []
                                        }, E
                                    }()), O.preVerifyStartTime = f();
                                    else {
                                        L.state = 1;
                                        for (var e = E._completes, t = 0, a = e.length; t < a; ++t) e[t]();
                                        E._completes = []
                                    }
                                })), y()
                            },
                            ready: function(e) {
                                0 != L.state ? e() : (E._completes.push(e), !k && B.debug && e())
                            },
                            error: function(e) {
                                M < "6.0.2" || (-1 == L.state ? e(L.data) : E._fail = e)
                            },
                            checkJsApi: function(e) {
                                var n = function(e) {
                                    var n = e.checkResult;
                                    for (var t in n) {
                                        var a = b[t];
                                        a && (n[a] = n[t], delete n[t])
                                    }
                                    return e
                                };
                                o("checkJsApi", {
                                    jsApiList: p(e.jsApiList)
                                }, (e._complete = function(e) {
                                    if (I) {
                                        var t = e.checkResult;
                                        t && (e.checkResult = JSON.parse(t))
                                    }
                                    e = n(e)
                                }, e))
                            },
                            onMenuShareTimeline: function(e) {
                                i(v.onMenuShareTimeline, {
                                    complete: function() {
                                        o("shareTimeline", {
                                            title: e.title || C,
                                            desc: e.title || C,
                                            img_url: e.imgUrl || "",
                                            link: e.link || location.href,
                                            type: e.type || "link",
                                            data_url: e.dataUrl || ""
                                        }, e)
                                    }
                                }, e)
                            },
                            onMenuShareAppMessage: function(e) {
                                i(v.onMenuShareAppMessage, {
                                    complete: function(n) {
                                        "favorite" === n.scene ? o("sendAppMessage", {
                                            title: e.title || C,
                                            desc: e.desc || "",
                                            link: e.link || location.href,
                                            img_url: e.imgUrl || "",
                                            type: e.type || "link",
                                            data_url: e.dataUrl || ""
                                        }) : o("sendAppMessage", {
                                            title: e.title || C,
                                            desc: e.desc || "",
                                            link: e.link || location.href,
                                            img_url: e.imgUrl || "",
                                            type: e.type || "link",
                                            data_url: e.dataUrl || ""
                                        }, e)
                                    }
                                }, e)
                            },
                            onMenuShareQQ: function(e) {
                                i(v.onMenuShareQQ, {
                                    complete: function() {
                                        o("shareQQ", {
                                            title: e.title || C,
                                            desc: e.desc || "",
                                            img_url: e.imgUrl || "",
                                            link: e.link || location.href
                                        }, e)
                                    }
                                }, e)
                            },
                            onMenuShareWeibo: function(e) {
                                i(v.onMenuShareWeibo, {
                                    complete: function() {
                                        o("shareWeiboApp", {
                                            title: e.title || C,
                                            desc: e.desc || "",
                                            img_url: e.imgUrl || "",
                                            link: e.link || location.href
                                        }, e)
                                    }
                                }, e)
                            },
                            onMenuShareQZone: function(e) {
                                i(v.onMenuShareQZone, {
                                    complete: function() {
                                        o("shareQZone", {
                                            title: e.title || C,
                                            desc: e.desc || "",
                                            img_url: e.imgUrl || "",
                                            link: e.link || location.href
                                        }, e)
                                    }
                                }, e)
                            },
                            updateTimelineShareData: function(e) {
                                o("updateTimelineShareData", {
                                    title: e.title,
                                    link: e.link,
                                    imgUrl: e.imgUrl
                                }, e)
                            },
                            updateAppMessageShareData: function(e) {
                                o("updateAppMessageShareData", {
                                    title: e.title,
                                    desc: e.desc,
                                    link: e.link,
                                    imgUrl: e.imgUrl
                                }, e)
                            },
                            startRecord: function(e) {
                                o("startRecord", {}, e)
                            },
                            stopRecord: function(e) {
                                o("stopRecord", {}, e)
                            },
                            onVoiceRecordEnd: function(e) {
                                i("onVoiceRecordEnd", e)
                            },
                            playVoice: function(e) {
                                o("playVoice", {
                                    localId: e.localId
                                }, e)
                            },
                            pauseVoice: function(e) {
                                o("pauseVoice", {
                                    localId: e.localId
                                }, e)
                            },
                            stopVoice: function(e) {
                                o("stopVoice", {
                                    localId: e.localId
                                }, e)
                            },
                            onVoicePlayEnd: function(e) {
                                i("onVoicePlayEnd", e)
                            },
                            uploadVoice: function(e) {
                                o("uploadVoice", {
                                    localId: e.localId,
                                    isShowProgressTips: 0 == e.isShowProgressTips ? 0 : 1
                                }, e)
                            },
                            downloadVoice: function(e) {
                                o("downloadVoice", {
                                    serverId: e.serverId,
                                    isShowProgressTips: 0 == e.isShowProgressTips ? 0 : 1
                                }, e)
                            },
                            translateVoice: function(e) {
                                o("translateVoice", {
                                    localId: e.localId,
                                    isShowProgressTips: 0 == e.isShowProgressTips ? 0 : 1
                                }, e)
                            },
                            chooseImage: function(e) {
                                o("chooseImage", {
                                    scene: "1|2",
                                    count: e.count || 9,
                                    sizeType: e.sizeType || ["original", "compressed"],
                                    sourceType: e.sourceType || ["album", "camera"]
                                }, (e._complete = function(e) {
                                    if (I) {
                                        var n = e.localIds;
                                        try {
                                            n && (e.localIds = JSON.parse(n))
                                        } catch (e) {}
                                    }
                                }, e))
                            },
                            getLocation: function(e) {},
                            previewImage: function(e) {
                                o(v.previewImage, {
                                    current: e.current,
                                    urls: e.urls
                                }, e)
                            },
                            uploadImage: function(e) {
                                o("uploadImage", {
                                    localId: e.localId,
                                    isShowProgressTips: 0 == e.isShowProgressTips ? 0 : 1
                                }, e)
                            },
                            downloadImage: function(e) {
                                o("downloadImage", {
                                    serverId: e.serverId,
                                    isShowProgressTips: 0 == e.isShowProgressTips ? 0 : 1
                                }, e)
                            },
                            getLocalImgData: function(e) {
                                !1 === N ? (N = !0, o("getLocalImgData", {
                                    localId: e.localId
                                }, (e._complete = function(e) {
                                    if (N = !1, j.length > 0) {
                                        var n = j.shift();
                                        wx.getLocalImgData(n)
                                    }
                                }, e))) : j.push(e)
                            },
                            getNetworkType: function(e) {
                                var n = function(e) {
                                    var n = e.errMsg;
                                    e.errMsg = "getNetworkType:ok";
                                    var t = e.subtype;
                                    if (delete e.subtype, t) e.networkType = t;
                                    else {
                                        var a = n.indexOf(":"),
                                            o = n.substring(a + 1);
                                        switch (o) {
                                            case "wifi":
                                            case "edge":
                                            case "wwan":
                                                e.networkType = o;
                                                break;
                                            default:
                                                e.errMsg = "getNetworkType:fail"
                                        }
                                    }
                                    return e
                                };
                                o("getNetworkType", {}, (e._complete = function(e) {
                                    e = n(e)
                                }, e))
                            },
                            openLocation: function(e) {
                                o("openLocation", {
                                    latitude: e.latitude,
                                    longitude: e.longitude,
                                    name: e.name || "",
                                    address: e.address || "",
                                    scale: e.scale || 28,
                                    infoUrl: e.infoUrl || ""
                                }, e)
                            }
                        }, a(_, "getLocation", (function(e) {
                            e = e || {}, o(v.getLocation, {
                                type: e.type || "wgs84"
                            }, (e._complete = function(e) {
                                delete e.type
                            }, e))
                        })), a(_, "hideOptionMenu", (function(e) {
                            o("hideOptionMenu", {}, e)
                        })), a(_, "showOptionMenu", (function(e) {
                            o("showOptionMenu", {}, e)
                        })), a(_, "closeWindow", (function(e) {
                            o("closeWindow", {}, e = e || {})
                        })), a(_, "hideMenuItems", (function(e) {
                            o("hideMenuItems", {
                                menuList: e.menuList
                            }, e)
                        })), a(_, "showMenuItems", (function(e) {
                            o("showMenuItems", {
                                menuList: e.menuList
                            }, e)
                        })), a(_, "hideAllNonBaseMenuItem", (function(e) {
                            o("hideAllNonBaseMenuItem", {}, e)
                        })), a(_, "showAllNonBaseMenuItem", (function(e) {
                            o("showAllNonBaseMenuItem", {}, e)
                        })), a(_, "scanQRCode", (function(e) {
                            o("scanQRCode", {
                                needResult: (e = e || {})
                                    .needResult || 0,
                                scanType: e.scanType || ["qrCode", "barCode"]
                            }, (e._complete = function(e) {
                                if (A) {
                                    var n = e.resultStr;
                                    if (n) {
                                        var t = JSON.parse(n);
                                        e.resultStr = t && t.scan_code && t.scan_code.scan_result
                                    }
                                }
                            }, e))
                        })), a(_, "openAddress", (function(e) {
                            o(v.openAddress, {}, (e._complete = function(e) {
                                e = c(e)
                            }, e))
                        })), a(_, "openProductSpecificView", (function(e) {
                            o(v.openProductSpecificView, {
                                pid: e.productId,
                                view_type: e.viewType || 0,
                                ext_info: e.extInfo
                            }, e)
                        })), a(_, "addCard", (function(e) {
                            for (var n = e.cardList, t = [], a = 0, i = n.length; a < i; ++a) {
                                var r = n[a],
                                    s = {
                                        card_id: r.cardId,
                                        card_ext: r.cardExt
                                    };
                                t.push(s)
                            }
                            o(v.addCard, {
                                card_list: t
                            }, (e._complete = function(e) {
                                var n = e.card_list;
                                if (n) {
                                    for (var t = 0, a = (n = JSON.parse(n))
                                        .length; t < a; ++t) {
                                        var o = n[t];
                                        o.cardId = o.card_id, o.cardExt = o.card_ext, o.isSuccess = !!o.is_succ, delete o.card_id, delete o.card_ext, delete o.is_succ
                                    }
                                    e.cardList = n, delete e.card_list
                                }
                            }, e))
                        })), a(_, "chooseCard", (function(e) {
                            o("chooseCard", {
                                app_id: B.appId,
                                location_id: e.shopId || "",
                                sign_type: e.signType || "SHA1",
                                card_id: e.cardId || "",
                                card_type: e.cardType || "",
                                card_sign: e.cardSign,
                                time_stamp: e.timestamp + "",
                                nonce_str: e.nonceStr
                            }, (e._complete = function(e) {
                                e.cardList = e.choose_card_info, delete e.choose_card_info
                            }, e))
                        })), a(_, "openCard", (function(e) {
                            for (var n = e.cardList, t = [], a = 0, i = n.length; a < i; ++a) {
                                var r = n[a],
                                    s = {
                                        card_id: r.cardId,
                                        code: r.code
                                    };
                                t.push(s)
                            }
                            o(v.openCard, {
                                card_list: t
                            }, e)
                        })), a(_, "consumeAndShareCard", (function(e) {
                            o(v.consumeAndShareCard, {
                                consumedCardId: e.cardId,
                                consumedCode: e.code
                            }, e)
                        })), a(_, "chooseWXPay", (function(e) {
                            o(v.chooseWXPay, s(e), e)
                        })), a(_, "openEnterpriseRedPacket", (function(e) {
                            o(v.openEnterpriseRedPacket, s(e), e)
                        })), a(_, "startSearchBeacons", (function(e) {
                            o(v.startSearchBeacons, {
                                ticket: e.ticket
                            }, e)
                        })), a(_, "stopSearchBeacons", (function(e) {
                            o(v.stopSearchBeacons, {}, e)
                        })), a(_, "onSearchBeacons", (function(e) {
                            i(v.onSearchBeacons, e)
                        })), a(_, "openEnterpriseChat", (function(e) {
                            o("openEnterpriseChat", {
                                useridlist: e.userIds,
                                chatname: e.groupName
                            }, e)
                        })), a(_, "launchMiniProgram", (function(e) {
                            o("launchMiniProgram", {
                                targetAppId: e.targetAppId,
                                path: h(e.path),
                                envVersion: e.envVersion
                            }, e)
                        })), a(_, "miniProgram", {
                            navigateBack: function(e) {
                                e = e || {}, m((function() {
                                    o("invokeMiniProgramAPI", {
                                        name: "navigateBack",
                                        arg: {
                                            delta: e.delta || 1
                                        }
                                    }, e)
                                }))
                            },
                            navigateTo: function(e) {
                                m((function() {
                                    o("invokeMiniProgramAPI", {
                                        name: "navigateTo",
                                        arg: {
                                            url: e.url
                                        }
                                    }, e)
                                }))
                            },
                            redirectTo: function(e) {
                                m((function() {
                                    o("invokeMiniProgramAPI", {
                                        name: "redirectTo",
                                        arg: {
                                            url: e.url
                                        }
                                    }, e)
                                }))
                            },
                            switchTab: function(e) {
                                m((function() {
                                    o("invokeMiniProgramAPI", {
                                        name: "switchTab",
                                        arg: {
                                            url: e.url
                                        }
                                    }, e)
                                }))
                            },
                            reLaunch: function(e) {
                                m((function() {
                                    o("invokeMiniProgramAPI", {
                                        name: "reLaunch",
                                        arg: {
                                            url: e.url
                                        }
                                    }, e)
                                }))
                            },
                            postMessage: function(e) {
                                m((function() {
                                    o("invokeMiniProgramAPI", {
                                        name: "postMessage",
                                        arg: e.data || {}
                                    }, e)
                                }))
                            },
                            getEnv: function(n) {
                                m((function() {
                                    n({
                                        miniprogram: "miniprogram" === e.__wxjs_environment
                                    })
                                }))
                            }
                        }), _),
                        q = 1,
                        R = {};
                    return S.addEventListener("error", (function(e) {
                        if (!I) {
                            var n = e.target,
                                t = n.tagName,
                                a = n.src;
                            if (("IMG" == t || "VIDEO" == t || "AUDIO" == t || "SOURCE" == t) && -1 != a.indexOf("wxlocalresource://")) {
                                e.preventDefault(), e.stopPropagation();
                                var o = n["wx-id"];
                                if (o || (o = q++, n["wx-id"] = o), R[o]) return;
                                R[o] = !0, wx.ready((function() {
                                    wx.getLocalImgData({
                                        localId: a,
                                        success: function(e) {
                                            n.src = e.localData
                                        }
                                    })
                                }))
                            }
                        }
                    }), !0), S.addEventListener("load", (function(e) {
                        if (!I) {
                            var n = e.target,
                                t = n.tagName;
                            if (n.src, "IMG" == t || "VIDEO" == t || "AUDIO" == t || "SOURCE" == t) {
                                var a = n["wx-id"];
                                a && (R[a] = !1)
                            }
                        }
                    }), !0), t && (e.wx = e.jWeixin = W), W
                }
            }))
        })
            .call(this, t("5a52")["default"])
    }
});