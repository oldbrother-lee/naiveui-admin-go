<?php
/**
 * 作者：lq
 * 邮箱：
 * 公司：
 **/
/**
 * Created by PhpStorm.
 * User: 12048
 * Date: 2017-11-13
 * Time: 11:05
 */

return [
    'default_return_type' => 'json',
    'view_replace_str' => [
        '__IMG__' => ROOT . 'public' . DS . 'yrapi' . DS . 'img',
        '__CSS__' => ROOT . 'public' . DS . 'yrapi' . DS . 'css',
        '__JS__' => ROOT . 'public' . DS . 'yrapi' . DS . 'js'
    ],
];