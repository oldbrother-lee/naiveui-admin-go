<?php

namespace app\api\controller;


use app\common\library\Createlog;
use app\common\library\KsAgent;
use app\common\library\Otherapi;
use app\common\library\SmsNotice;
use app\common\model\Porder;
use Payapi\Jindjuhe;
use Payapi\Leshua;
use think\Log;
use Util\Pinyin;

/**
 * Class test
 * 开放控制器，登录注册等操作
 */
class Daichong extends \app\common\controller\Base
{


    public function login(){

        $user = input('');
        $pwd = input('');



    }





}
