<?php

return [
    'app\common\command\Crontab60',
    'app\common\command\Crontab30',//稀土 取单心跳
    'app\common\command\Crontab5',//超时退单
    'app\common\command\Crontab1',//提交订单
];
